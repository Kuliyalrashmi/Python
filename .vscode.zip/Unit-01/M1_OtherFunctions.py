def add(x,y):
#This function adds two varisbles a and b and returns the sum of a and b
    return x+y

def sub(x,y):
#this functions substracts two variables a and b and returns the substraction  of a and b
    return x-y

print("Hello World 1")

def main():  #cross validation
    #this function is testing all the functionalities 
    if add(1,2)==3:
        print("Add functionality is working fine!")
    if sub(3,2)==1:
        print("sub functionality is working fine!")

print(__name__)
if __name__=="__main__":  # Here name variable stores the name of the file in which the code is written main will be replace by the name of the file
    main()                #main changes to file name when 


print("Hello World 3")

