##Declaration of a variable is not required in python.(this is single line comment)
''' this is multiline comment
'''
x=5
y="john"
print(x)
print(y)
#Over Written feature of Python
x=4
x="Sally" #now the value of x become sally which is of string type
print(x)
#casting a value
x=str(321)  # x will be 321
y=int(3)    
z=float(3)
print(x)
print(y)
print(z)
#python string /character storage
#double quote and single quote
x="John"
x='John'
x="b"
x='John'
print(x)
