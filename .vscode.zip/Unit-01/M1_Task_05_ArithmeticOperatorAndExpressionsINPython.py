# Arithmetic Operator
'''
  Addition[+]
  Substraction[-]
  Multiplication[*]
  Division      [/]
  Modulus       [%]
  Exponentiation [**]
  Floor Division [//]
'''
val1=2
val2=3
res=val1+val2
print(res)

res=val1-val2
print(res)


res=val1*val2
print(res)


res=val1/val2
print(res)

res=val1%val2
print(res)

res=val1**val2
print(res)

res=val1//val2
print(res)

#EXPRESSION


#CONSTANT EXPRESSION
x=15+3
print(x)

#arithmetic expression
x=40
y=12
print(x+y)

#integral expression
x=13
y=12.0
z=x+int(y)
print(z)

#floating expression'
a=13
b=3
print(13/3)

# Relational expression
a=21
b=13
c=40
d=37
p=(a+b)>=(c-d)
print(p)

#Logical Expressions
p=(10==9)
q=(7>5)
r=p and q
s=p or q
t=not p
print(r)
print(s)
print(t)
































