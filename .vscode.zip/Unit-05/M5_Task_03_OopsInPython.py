#OOPs concepts in Python 
'''
1. Class Definition syntax and how to create an objects of class
2. Instance variables
3. Inheritance and Multiple Inheritance
4. Polynorphism
  -Overloading
  -Overriding
  -Data Hiding
5. Constructors in Python

'''
# Class
class BaseClass:
 # Instance Variable
 x = 5

# Object creation
obj = BaseClass()
print(obj.x)

